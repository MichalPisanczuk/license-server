# API

## Dostępne endpointy REST

Wtyczka udostępnia publiczne REST API w przestrzeni nazw `myshop/v1`. Wszystkie adresy są dostępne pod prefiksem URL
`https://twoj‑sklep.pl/wp-json/myshop/v1/…` (podmień domenę na swój sklep). Endpoints akceptują i zwracają dane w formacie
JSON. Autoryzacja odbywa się za pomocą klucza licencyjnego oraz mechanizmów podpisywania linków.

### 1. `POST /license/activate`

Służy do **aktywacji** licencji na danej domenie. Wtyczka kliencka wywołuje ten endpoint po wprowadzeniu klucza przez
użytkownika lub przy pierwszym uruchomieniu. Serwer sprawdza status licencji, limit aktywacji i przypisuje domenę do
licencji.

**Parametry w treści żądania (`body`):**

| Nazwa        | Typ      | Wymagane | Opis                                                                           |
|--------------|----------|:--------:|---------------------------------------------------------------------------------|
| `license_key`| `string` |   tak    | Klucz licencyjny wygenerowany podczas zakupu.                                   |
| `domain`     | `string` |   tak    | Domenę instalacji pluginu (najlepiej `home_url()` w WordPressie), np. `example.com` |

**Przykład zapytania (PHP / wp_remote_post):**

```php
$response = wp_remote_post('https://twoj‑sklep.pl/wp-json/myshop/v1/license/activate', [
    'timeout' => 15,
    'body'    => [
        'license_key' => $license_key,
        'domain'      => home_url(),
    ],
]);
$data = json_decode(wp_remote_retrieve_body($response), true);
```

**Przykładowa odpowiedź:**

```json
{
  "ok": true,
  "status": "active",
  "expires_at": "2026‑09‑24T00:00:00+00:00",
  "remaining_activations": 0,
  "message": "Licencja aktywowana na example.com"
}
```

W przypadku błędu serwer zwróci `ok: false` oraz informację o przyczynie (np. `limit_exceeded`, `invalid_key`).

### 2. `POST /license/validate`

Służy do **cyklicznej walidacji** (heartbeat) licencji już aktywowanej. Wtyczka kliencka powinna wywoływać ten endpoint
regularnie (np. raz dziennie), aby zaktualizować status licencji oraz sprawdzić ewentualne zmiany (wygaśnięcie,
anulowanie subskrypcji). Serwer aktualizuje pole `last_seen_at` w tabeli aktywacji.

**Parametry w treści żądania:**

| Nazwa        | Typ      | Wymagane | Opis                                                                                 |
|--------------|----------|:--------:|-------------------------------------------------------------------------------------|
| `license_key`| `string` |   tak    | Klucz licencyjny.                                                                    |
| `domain`     | `string` |   tak    | Domenę instalacji.                                                                  |

**Przykładowa odpowiedź:**

```json
{
  "ok": true,
  "status": "active",
  "reason": "ok",
  "expires_at": "2026‑09‑24T00:00:00+00:00",
  "grace_until": null
}
```

Pole `reason` może przyjmować wartości: `ok`, `expired`, `payment_failed`, `cancelled`, `on_hold` lub `limit_exceeded`.
Jeżeli `ok: false`, aplikacja kliencka powinna poinformować użytkownika o braku ważnej licencji i zablokować
aktualizacje.

### 3. `POST /updates/check`

Sprawdza, czy dla podanej wtyczki dostępna jest nowsza wersja. Endpoint zwraca metadane zgodne z oczekiwaniami
WordPressa, dzięki czemu integruje się z systemem aktualizacji. Wtyczka kliencka powinna wywoływać ten endpoint w
hooku `pre_set_site_transient_update_plugins` tylko wtedy, gdy licencja jest aktywna.

**Parametry w treści żądania:**

| Nazwa         | Typ      | Wymagane | Opis                                                                     |
|---------------|----------|:--------:|---------------------------------------------------------------------------|
| `license_key` | `string` |   tak    | Klucz licencyjny.                                                        |
| `slug`        | `string` |   tak    | Unikalny slug/folder wtyczki klienta, np. `moja‑wtyczka`.                 |
| `version`     | `string` |   tak    | Aktualnie zainstalowana wersja.                                          |
| `domain`      | `string` |   tak    | Domenę instalacji.                                                      |

**Przykładowa odpowiedź, gdy dostępna jest aktualizacja:**

```json
{
  "ok": true,
  "new_version": "1.2.3",
  "package": "https://twoj‑sklep.pl/wp-json/myshop/v1/updates/download?signature=…&expires=…",
  "tested": "6.6",
  "requires": "5.8",
  "changelog": "– Poprawa wydajności\n– Dodanie nowej funkcji"
}
```

Pole `package` zawiera **podpisany link** ważny przez ograniczony czas (TTL określony w ustawieniach globalnych).
Wtyczka kliencka powinna przekazać ten link do WordPressa jako `package` w strukturze `stdClass` w odpowiedzi z
`pre_set_site_transient_update_plugins`.

Jeśli nie ma nowszej wersji albo licencja jest nieważna, serwer zwróci `ok: false` wraz z kluczem `reason` i
komunikatem.

### 4. `GET /updates/download`

Endpoint wydaje plik ZIP z najnowszą wersją wtyczki. **Nie** należy wywoływać go bezpośrednio – wtyczka kliencka
korzysta z linku zwróconego w polu `package` z poprzedniego endpointu. Podpisany link zawiera parametry:

- `expires` – znacznik czasu (UNIX timestamp) ważności linku,
- `signature` – podpis HMAC wyliczany po stronie serwera (nie publikujemy algorytmu, aby utrudnić podrabianie),
- opcjonalnie: `license_id` i `release_id` – wewnętrzne identyfikatory.

Serwer przed wysłaniem pliku weryfikuje poprawność podpisu i datę ważności. W razie naruszenia zwraca błąd `403`.

**Przykładowy flow aktualizacji w kliencie:**

1. Wtyczka wywołuje `/updates/check` z aktualnym numerem wersji.
2. Jeśli `new_version > current_version`, WordPress otrzymuje w obiekcie `package` podpisany link.
3. WordPress pobiera ZIP z `/updates/download?...` i instaluje aktualizację.

### Uwagi dotyczące użycia API

- Wszystkie endpointy powinny być wywoływane metodami HTTP zgodnie z opisem (`POST` lub `GET`).
- Używaj bezpiecznych połączeń HTTPS.
- Nie przekazuj klucza licencyjnego w parametrach URL – zawsze w treści zapytania (`body`).
- W przypadku błędów sieciowych lub limitów API wtyczka kliencka powinna obsłużyć wyjątki i ponowić próbę później.

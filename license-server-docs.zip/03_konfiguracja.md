# Konfiguracja

## Oznaczanie produktu jako licencjonowany

1. W edycji produktu WooCommerce (np. „Moja Wtyczka PRO”) przejdź do metaboxu **Licencja** (dodawanego przez wtyczkę).
2. Zaznacz pole **„Jest licencjonowany”**.
3. Wprowadź identyfikator wtyczki (slug) – folder wtyczki klienta, np. `moja-wtyczka`.
4. Ustaw **limit aktywacji** (np. `1`, `3`, `nielimitowana`).
5. (Opcjonalnie) Ustaw datę ważności licencji w dniach – w przypadku licencji okresowych (subskrypcja automatycznie zarządza datą wygasania).

Po zapisaniu produktu każdy zakup tego produktu będzie skutkował wygenerowaniem osobnej licencji.

## Ustawienia globalne

W panelu administracyjnym WordPressa znajduje się strona **Ustawienia → License Server**, gdzie możesz:

- Określić długość życia podpisanych linków (TTL) w minutach.
- Zdefiniować domyślny okres łaski po wygaśnięciu subskrypcji (grace period).
- Włączyć logowanie zdarzeń (przydatne podczas debugowania).
- Skonfigurować dopuszczalne domeny deweloperskie (np. `localhost`, `*.test`), które nie będą liczone do limitu aktywacji.

## Panel „Moje konto”

Po zalogowaniu do sklepu klient może wejść w zakładkę **Moje konto → Licencje**, gdzie zobaczy listę swoich licencji, ich status, datę wygaśnięcia oraz aktywne domeny. Klienci, którzy kupili tylko produkty nieobjęte licencją (np. e-booki), nie zobaczą tej zakładki.

## Integracja z Woo Subscriptions

Jeśli licencja jest sprzedawana jako subskrypcja roczna:

1. Upewnij się, że wtyczka **WooCommerce Subscriptions** jest aktywna.
2. Skonfiguruj produkt jako subskrypcję (Okres rozliczeniowy: 1 rok, Odnowienie automatyczne).
3. W momencie odnowienia subskrypcji wtyczka przedłuży ważność licencji o kolejny rok.
4. Jeśli płatność się nie powiedzie lub subskrypcja zostanie anulowana, licencja automatycznie zmieni status na `inactive`, a klient otrzyma informację o konieczności odnowienia.

Te mechanizmy działają w oparciu o hooki `woocommerce_subscription_status_updated` oraz `woocommerce_subscription_renewal_payment_complete`.
# Integracja klienta

Wtyczka serwerowa udostępnia **bibliotekę kliencką** (katalog `myshop-license-client`) służącą do łatwej integracji
w dowolnej wtyczce sprzedawanej w Twoim sklepie. Biblioteka implementuje rejestrację licencji, walidację oraz
mechanizm aktualizacji w oparciu o REST API serwera licencji.

## Struktura biblioteki

Biblioteka zawiera następujące pliki:

- `Client.php` – główna klasa zarządzająca kluczem, aktywacją i walidacją licencji.
- `Updater.php` – integracja z WordPressowym systemem aktualizacji (`pre_set_site_transient_update_plugins`).
- `AdminPage.php` – prosty interfejs w panelu wtyczki umożliwiający podanie klucza licencyjnego i wyświetlający
  status subskrypcji.
- `Notices.php` – generuje powiadomienia w kokpicie (np. o wygasłej licencji).
- `Http.php` – proste metody wrapperów `wp_remote_post()` i `wp_remote_get()` z obsługą błędów.
- `Utils.php` – drobne funkcje pomocnicze (np. normalizacja domeny, pobieranie sluga).

## Włączenie biblioteki w sprzedawanej wtyczce

1. Skopiuj katalog `myshop-license-client` do katalogu `inc/license/` w Twojej wtyczce.
2. W głównym pliku wtyczki (np. `moja‑wtyczka.php`) zdefiniuj stałe konfiguracyjne:

```php
define('MYPLUGIN_VERSION', '1.0.0');             // aktualna wersja wtyczki
define('MYPLUGIN_SLUG', 'moja‑wtyczka');          // slug (folder) wtyczki
define('MYPLUGIN_FILE', __FILE__);                // główny plik pluginu
define('MYSHOP_API_BASE', 'https://twoj‑sklep.pl/wp-json/myshop/v1');
```

3. Załaduj pliki biblioteki i zarejestruj komponenty:

```php
require_once __DIR__ . '/inc/license/Client.php';
require_once __DIR__ . '/inc/license/Updater.php';
require_once __DIR__ . '/inc/license/AdminPage.php';
require_once __DIR__ . '/inc/license/Notices.php';

use MyShop\LicClient\Client;
use MyShop\LicClient\Updater;
use MyShop\LicClient\AdminPage;
use MyShop\LicClient\Notices;

$client = new Client([
    'api_base' => MYSHOP_API_BASE,
    'slug'     => MYPLUGIN_SLUG,
    'version'  => MYPLUGIN_VERSION,
    'file'     => MYPLUGIN_FILE,
]);

(new Updater($client))->register();
(new AdminPage($client))->register();
(new Notices($client))->register();
```

4. Opcjonalnie: jeśli chcesz kontrolować częstotliwość walidacji licencji, możesz ustawić własny harmonogram w klasie
`Client` lub dodać własne zadania cron.

## Użycie biblioteki

### Podanie klucza licencyjnego

Klient wpisuje klucz licencyjny w ustawieniach wtyczki (strona z `AdminPage`). Biblioteka zapisuje go w opcji
WordPressa (`myshop_license_key`) i automatycznie wywołuje `/license/activate`. Jeśli aktywacja przebiegnie
pomyślnie, w ustawieniach pojawi się informacja o statusie licencji, dacie wygaśnięcia oraz liczbie dostępnych
aktywacji.

### Walidacja licencji

Klasa `Client` przy pomocy WordPressowego cron rejestruje zadanie (domyślnie dwa razy dziennie), które wywołuje
`/license/validate`. Dzięki temu licencja jest regularnie synchronizowana z serwerem (aktualizacja statusu, daty
wygaśnięcia, liczby aktywacji). W razie problemów (wygaśnięcie, nieopłacona subskrypcja) biblioteka umieszcza
informację w kokpicie.

### Aktualizacje wtyczki

`Updater` integruje się z mechanizmem aktualizacji WordPressa w taki sposób, aby WordPress wykrywał nowe wersje
tylko wtedy, gdy licencja jest aktywna. Działa to następująco:

1. Hook `pre_set_site_transient_update_plugins` sprawdza, czy wtyczka posiada zarejestrowany klucz licencyjny i czy
   licencja jest aktywna (odczytywane z opcji zapisywanej przez `Client`).
2. Jeśli tak, `Updater` wysyła zapytanie `/updates/check` z aktualną wersją i slugiem. Jeśli dostępna jest nowsza
   wersja, dodaje wpis do tablicy odpowiedzi WordPressa (`$transient->response[$plugin_file]`).
3. WordPress automatycznie pobiera i instaluje aktualizację, korzystając z podpisanego linku zwróconego przez API.
4. Po zakończeniu aktualizacji `Client` może ponownie wywołać `/license/validate`, aby odświeżyć status.

### Obsługa wyjątków

Biblioteka obsługuje typowe sytuacje, np. brak aktywnej licencji, limit aktywacji lub niepowodzenie połączenia.
W panelu admina pojawią się stosowne komunikaty. Możesz dostosować treść tych komunikatów modyfikując klasę
`Notices` lub pliki językowe wtyczki.

## Tworzenie własnej integracji

Biblioteka jest przykładowa; możesz napisać własne rozwiązanie, korzystając bezpośrednio z API. W takim wypadku:

1. Zapamiętaj klucz licencyjny w bezpieczny sposób (`update_option`).
2. Wywołaj `POST /license/activate` i zapisz wynik (status, data wygaśnięcia, maksymalne aktywacje).
3. Cyklicznie wywołuj `POST /license/validate` (np. z cronem) w celu utrzymania synchronizacji.
4. W hooku `pre_set_site_transient_update_plugins` wywołaj `POST /updates/check` i na podstawie odpowiedzi dodaj
   pakiet do `$transient->response`. Użyj linku `package` tylko w czasie jego ważności.
5. Obsłuż scenariusze braku aktywnej licencji lub wygaśnięcia subskrypcji, aby zablokować aktualizacje i pokazać
   informację użytkownikowi.

Pamiętaj, że pełna implementacja powinna również obsługiwać subskrypcje roczne, zgodnie z opisem w sekcji
**Konfiguracja**.

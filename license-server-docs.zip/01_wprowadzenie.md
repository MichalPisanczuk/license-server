# Wprowadzenie

## Cel wtyczki

Wtyczka **License Server (MyShop)** została zaprojektowana do zarządzania licencjami i aktualizacjami wtyczek sprzedawanych w sklepie WooCommerce. Pozwala generować klucze licencyjne przypisane do konkretnego klienta i produktu, aktywować je na wybranych domenach, weryfikować ważność licencji oraz bezpiecznie dostarczać aktualizacje. 

Główne funkcje wtyczki:
- **Generowanie licencji** po zakupie produktu oznaczonego jako licencjonowany.
- **Aktywacja i walidacja klucza** przez REST API z przypisaniem do domeny.
- **Obsługa subskrypcji** rocznych – powiązanie statusu subskrypcji z ważnością licencji.
- **Kontrola liczby aktywacji** (limit domen).
- **Dystrybucja aktualizacji** wtyczek poprzez bezpieczne, podpisane linki z TTL.
- **Integracja z WooCommerce** i Woo Subscriptions.
- **Panel administracyjny** w WordPressie umożliwiający podgląd i edycję licencji, wydawanie nowych wersji, ustawienia globalne.
- **Krótki kod** (shortcode) umożliwiający klientowi podgląd licencji w zakładce „Moje konto”.

Wtyczka została napisana w oparciu o nowoczesne standardy PHP, autoloading PSR‑4 i komponentową strukturę kodu, co ułatwia rozwój i utrzymanie.

## Zakres dokumentacji

Dokumentacja podzielona jest na następujące sekcje:

1. **Instalacja** – sposób instalacji, wymagania, aktywacja i dezaktywacja.
2. **Konfiguracja** – ustawienia produktu i globalne opcje wtyczki.
3. **API** – opis udostępnionych endpointów REST API z przykładami.
4. **Baza danych** – struktura tabel i opis kolumn.
5. **Integracja klienta** – jak zintegrować bibliotekę kliencką w sprzedawanej wtyczce.
6. **Bezpieczeństwo** – opis zastosowanych mechanizmów i wskazówki.
7. **Przykłady** – typowe scenariusze użycia krok po kroku.

Niniejszy zestaw plików stanowi kompletny przewodnik po wtyczce. Każdy plik opisuje oddzielny aspekt funkcjonalności, dzięki czemu można łatwo znaleźć potrzebne informacje.
# Baza danych

Wtyczka podczas instalacji tworzy trzy główne tabele w bazie danych (prefiksowane domyślnym przedrostkiem
WordPressa, np. `wp_plugin_licenses`). Struktura została zaprojektowana tak, aby łatwo rozszerzać funkcjonalność i
utrzymywać spójność danych. Do utworzenia i aktualizacji struktur wykorzystywana jest funkcja `dbDelta()` dostępna
w WordPressie.

## Tabela `plugin_licenses`

Reprezentuje pojedynczy klucz licencyjny przypisany do konkretnego użytkownika i produktu. Pola tabeli:

| Kolumna             | Typ                 | Opis                                                                                       |
|---------------------|---------------------|--------------------------------------------------------------------------------------------|
| `id`                | BIGINT UNSIGNED PK  | Unikalny identyfikator licencji.                                                           |
| `user_id`           | BIGINT UNSIGNED     | ID użytkownika WordPressa, który zakupił licencję.                                         |
| `product_id`        | BIGINT UNSIGNED     | ID produktu WooCommerce (wtyczki).                                                         |
| `subscription_id`   | BIGINT UNSIGNED     | ID subskrypcji WooCommerce (jeśli licencja jest częścią subskrypcji rocznej, inaczej NULL). |
| `license_key`       | VARCHAR(64)         | Wygenerowany łańcuch alfanumeryczny będący kluczem licencyjnym.                             |
| `status`            | VARCHAR(20)         | Stan licencji: `active`, `inactive`, `expired`, `revoked`.                                  |
| `expires_at`        | DATETIME NULLABLE   | Data i godzina wygaśnięcia licencji (NULL dla licencji dożywotnich).                        |
| `grace_until`       | DATETIME NULLABLE   | Opcjonalny okres łaski po wygaśnięciu (`expires_at + X dni`), w którym aktualizacje nadal są dostępne. |
| `max_activations`   | INT UNSIGNED        | Limit aktywacji (domyślnie 1, 0 oznacza brak limitu).                                        |
| `created_at`        | DATETIME            | Data utworzenia rekordu.                                                                   |
| `updated_at`        | DATETIME            | Data ostatniej modyfikacji rekordu (automatycznie aktualizowana).                           |

Indeksy: klucz główny (`id`), indeks na kolumnie `license_key` (wyszukiwanie klucza), indeks złożony na
(`user_id`, `product_id`), aby szybko znaleźć licencje użytkownika do danego produktu.

## Tabela `plugin_activations`

Rejestruje **aktywacje** klucza licencyjnego na konkretnych domenach. Umożliwia kontrolę liczby aktywnych
instalacji oraz ich dezaktywację. Kolumny:

| Kolumna           | Typ                 | Opis                                                                                          |
|-------------------|---------------------|-----------------------------------------------------------------------------------------------|
| `id`              | BIGINT UNSIGNED PK  | Unikalny identyfikator aktywacji.                                                             |
| `license_id`      | BIGINT UNSIGNED     | Odwołanie do tabeli `plugin_licenses`.                                                         |
| `domain`          | VARCHAR(255)        | Nazwa domeny, na której aktywowano licencję (bez protokołu i subdomeny `www`).                |
| `ip_hash`         | CHAR(64)            | Hash IP (SHA‑256) zapisany w celu ewentualnego audytu, bez przechowywania pełnego IP.          |
| `activated_at`    | DATETIME            | Data i godzina aktywacji.                                                                     |
| `last_seen_at`    | DATETIME            | Data ostatniej walidacji (heartbeat) przez wtyczkę kliencką.                                  |

Unikalny indeks (`license_id`, `domain`) zapobiega wielokrotnym wpisom dla tej samej licencji i domeny. Usunięcie
rekordu z tej tabeli dezaktywuje licencję na danej domenie i zwalnia slot w limicie aktywacji.

## Tabela `plugin_releases`

Przechowuje informacje o opublikowanych wersjach wtyczek. Do każdej wersji przypisany jest plik ZIP z nową
wersją. Wiersz zostaje utworzony przez administratora w panelu „Wydania” lub w dowolny inny sposób (np. skrypt
CI/CD).

| Kolumna            | Typ                 | Opis                                                                                                  |
|--------------------|---------------------|-------------------------------------------------------------------------------------------------------|
| `id`               | BIGINT UNSIGNED PK  | Unikalny identyfikator wydania.                                                                       |
| `product_id`       | BIGINT UNSIGNED     | ID produktu WooCommerce, którego dotyczy wydanie.                                                     |
| `version`          | VARCHAR(20)         | Numer wersji semantycznej, np. `1.2.3`.                                                               |
| `zip_path`         | VARCHAR(255)        | Ścieżka do pliku ZIP przechowywanego w `storage/releases/`.                                           |
| `checksum_sha256`  | CHAR(64)            | Hash SHA‑256 pliku ZIP (spójność, weryfikacja integralności).                                          |
| `min_wp`           | VARCHAR(10)         | Minimalna wersja WordPress wymagana przez wydanie (np. `5.8`).                                        |
| `min_php`          | VARCHAR(10)         | Minimalna wersja PHP wymagana przez wydanie (np. `7.4`).                                              |
| `changelog`        | TEXT                | Lista zmian w formacie Markdown (używana w panelu „Co nowego” i API).                                |
| `released_at`      | DATETIME            | Data opublikowania wydania.                                                                          |

Na podstawie tabeli `plugin_releases` API `updates/check` zwraca metadane aktualizacji. Aktualna wersja
identyfikowana jest jako wiersz z największym `released_at` i numerem wersji większym niż podany przez klienta.

## Zarządzanie danymi

- **Migracje** – Wtyczka korzysta z pliku `includes/Data/Migrations.php`, który definiuje funkcję `Migrations::run()`
  wywoływaną przy aktywacji. `dbDelta()` automatycznie tworzy nowe kolumny lub tabele, ale nie usuwa danych.
- **Usuwanie** – Plik `uninstall.php` (w wersji pełnej wtyczki) jest wywoływany podczas trwałego usunięcia wtyczki w
  WordPressie. Możesz tam zaimplementować kasowanie tabel (`DROP TABLE`) i innych danych, jeśli chcesz. Zaleca się
  wykonywanie kopii zapasowych przed usunięciem.
- **Optymalizacja** – Dobrą praktyką jest okresowe czyszczenie nieużywanych aktywacji (np. `last_seen_at` starsze
  niż 90 dni) w celu zwolnienia limitów. Można to zrobić za pomocą zadania cron w pliku `Cron/Heartbeat.php`.

# Bezpieczeństwo

Wtyczka **License Server** została zaprojektowana z myślą o bezpieczeństwie dystrybucji komercyjnych wtyczek. Poniżej
omówiono kluczowe mechanizmy oraz najlepsze praktyki, które powinny być stosowane zarówno po stronie serwera,
jak i klienta.

## Podpisane linki (signed URLs)

Do udostępniania plików ZIP z aktualizacjami wtyczka wykorzystuje podpisane linki. Składają się z adresu do
endpointu `/updates/download` oraz parametrów:

- `expires` – czas wygaśnięcia linku (timestamp UNIX),
- `signature` – podpis HMAC obliczony ze ścieżki, czasu i identyfikatorów, przy użyciu tajnego klucza serwera.

Przed zwróceniem pliku serwer sprawdza, czy parametr `expires` nie jest w przeszłości oraz czy podpis odpowiada
danym parametrom. Link jest ważny tylko przez krótki czas (domyślnie 5 minut, konfigurowalny w ustawieniach). To
minimalizuje ryzyko kradzieży i udostępniania linków.

## Normalizacja domeny

W momencie aktywacji licencji domena jest normalizowana – usuwany jest protokół (`http://`, `https://`) oraz
prefiks `www`. Dzięki temu `example.com` i `www.example.com` traktowane są jako ta sama domena. Wtyczka ignoruje
również ścieżki i subdomeny zapisywane w adresie instalacji. Porównanie domeny wykonuje się w sposób case‑insensitive.

## Limit aktywacji i wiązanie domeny

Każda licencja może mieć ograniczoną liczbę aktywacji (`max_activations`). Przy aktywacji domena jest zapisywana w
tabeli `plugin_activations`. Przekroczenie limitu skutkuje błędem `limit_exceeded`. Aby zwolnić slot aktywacji,
możesz usunąć konkretną domenę w panelu administratora (zakładka „Licencje”).

## Hash IP i prywatność

W tabeli `plugin_activations` zapisywany jest hash IP (`ip_hash`) zamiast pełnego adresu IP. Używany jest algorytm
SHA‑256, aby zapewnić anonimowość użytkowników i zgodność z RODO. Wtyczka nie przechowuje pełnych adresów IP ani
dodatkowych danych osobowych.

## Mechanizm HMAC i tajny klucz

Podpisy są generowane przy użyciu algorytmu HMAC SHA‑256. Tajny klucz serwera przechowywany jest w pliku wtyczki
(np. w `wp-config.php` możesz zdefiniować stałą `LSR_SECRET_KEY`) i używany do generowania podpisów. Klient nie zna
tego klucza, co uniemożliwia podrobienie podpisu. **Nigdy nie udostępniaj klucza publicznie**. Zaleca się
przechowywanie go poza repozytorium kodu (np. w pliku konfiguracyjnym środowiska). W razie wycieku możesz
przeprowadzić rotację klucza i unieważnić stare podpisy.

## Rate limiting (ograniczenie zapytań)

Aby przeciwdziałać nadużyciom, wtyczka implementuje prosty limiter zapytań per IP i per klucz licencyjny. Jeśli
wykryte zostanie zbyt wiele zapytań w krótkim czasie, API zwróci błąd `429 Too Many Requests`. Parametry limitów
można modyfikować w klasie `RateLimiter`.

## Domena deweloperska i środowiska testowe

W ustawieniach globalnych można zdefiniować listę dozwolonych domen deweloperskich (np. `localhost`, `*.test`).
Aktywacje na takich domenach nie obniżają licznika `max_activations`. To ułatwia prace testowe, ale pamiętaj, żeby
lista domen deweloperskich była ograniczona do zaufanych wzorców.

## Aktualizacje zależne od subskrypcji

Jeżeli korzystasz z modelu subskrypcji rocznej, status licencji jest bezpośrednio zależny od statusu subskrypcji
WooCommerce. W przypadku opóźnienia w płatności lub anulowania subskrypcji licencja przechodzi w stan `inactive`, a
aktualizacje są blokowane. To zapobiega korzystaniu z aktualizacji bez opłaconego abonamentu.

## Zalecenia dotyczące wtyczki klienckiej

- **Używaj HTTPS** – Połączenia z API powinny być szyfrowane. Nie wysyłaj klucza licencyjnego w adresie URL.
- **Chroń klucz** – Klucz licencyjny jest tokenem dostępu. Przechowuj go w bazie (np. `wp_options`), nie
  trzymając w plikach publicznych. Jeśli klucz wycieknie, zresetuj go w panelu admina.
- **Obsługa błędów** – Zaimplementuj mechanizmy retry dla krótkotrwałych problemów sieciowych i informuj
  użytkownika o ewentualnym problemie z licencją.
- **Aktualizacje** – Korzystaj tylko z podpisanych linków generowanych przez API. Nie próbuj tworzyć własnych URL.

Zastosowanie powyższych zasad pozwala ograniczyć ryzyko piractwa i nadużyć, jednocześnie zapewniając płynne
doświadczenie użytkownika.

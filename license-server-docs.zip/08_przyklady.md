# Przykłady użycia

Poniższe scenariusze pokazują, jak w praktyce działa wtyczka **License Server** i jak można z niej skorzystać.

## 1. Zakup i aktywacja licencji przez klienta

1. **Klient kupuje produkt licencjonowany** w sklepie WooCommerce (np. „Moja Wtyczka PRO”).
2. Po opłaceniu zamówienia wtyczka serwerowa generuje klucz licencyjny i przypisuje go do użytkownika. Klucz jest
   dostępny w zakładce **Moje konto → Licencje** oraz przesyłany w e‑mailu. Załóżmy, że klucz to `ABCDEF123456`.
3. Klient loguje się na stronie swojej instalacji WordPressa i w panelu wtyczki (Udostępnionym przez bibliotekę
   kliencką) podaje klucz `ABCDEF123456`. Wtyczka wysyła zapytanie `POST /license/activate` z domeną `example.com`.
4. Serwer sprawdza, czy licencja jest aktywna i czy limit aktywacji nie został przekroczony, po czym zwraca
   odpowiedź `ok: true`. Licencja jest aktywowana na domenie `example.com`.
5. W ustawieniach wtyczki klient widzi status licencji (aktywny), datę wygaśnięcia oraz liczbę dostępnych aktywacji
   (np. `remaining_activations: 0` przy limicie 1).

## 2. Sprawdzanie dostępności aktualizacji

1. Wtyczka kliencka reaguje na WordPressowy hook `pre_set_site_transient_update_plugins` i wywołuje `POST /updates/check`.
2. Jeśli serwer ma nową wersję (np. `1.2.3`), zwraca informację o aktualizacji oraz podpisany link do pobrania pakietu.
3. WordPress wyświetla w standardowy sposób powiadomienie „Dostępna jest nowa wersja wtyczki Moja Wtyczka PRO”.
4. Po kliknięciu „Aktualizuj teraz” WordPress pobiera ZIP z `/updates/download` (korzystając z linku z pola
   `package`) i instaluje nową wersję. Podczas instalacji licencja jest ponownie weryfikowana; jeśli licencja
   jest nieaktywna, instalacja zostanie zablokowana.

## 3. Wygaśnięcie subskrypcji i blokada aktualizacji

1. Klient ma subskrypcję roczną; odnowienie nie powiodło się (np. brak środków). Wtyczka serwerowa, dzięki
   hookom Woo Subscriptions, zmienia status licencji na `inactive`.
2. Podczas następnego heartbeat `POST /license/validate` zwróci `status: inactive` z `reason: payment_failed`.
3. Wtyczka kliencka zapisuje nowy status i wyświetla w ustawieniach komunikat „Twoja subskrypcja wygasła. Odnów,
   aby otrzymywać aktualizacje.”.
4. W hooku aktualizacji WordPressa `pre_set_site_transient_update_plugins` wtyczka nie dodaje wpisu o aktualizacji,
   ponieważ licencja jest nieaktywna. W ten sposób nowe wersje nie są oferowane, dopóki klient nie odnowi subskrypcji.

## 4. Przekroczenie limitu aktywacji

1. Licencja ma ustawiony limit aktywacji `1` (`max_activations = 1`). Użytkownik aktywował ją na domenie
   `example.com`.
2. Próbuje teraz aktywować licencję na drugiej domenie `second.com`. Wtyczka kliencka wysyła zapytanie
   `POST /license/activate` z domeną `second.com`.
3. Serwer sprawdza liczbę istniejących aktywacji i zwraca `ok: false`, `reason: limit_exceeded`, `message:
   'Limit aktywacji przekroczony'`.
4. Klient może zalogować się do sklepu, wejść w „Moje konto → Licencje” i dezaktywować licencję na domenie
   `example.com`. Po zwolnieniu slotu może ponownie spróbować aktywacji na `second.com`.

## 5. Własna aplikacja kliencka (bez biblioteki)

W razie potrzeby możesz napisać własną logikę komunikacji z API. Przykładowy kod w PHP (korzystający z
`wp_remote_post`) pokazuje podstawowy flow:

```php
$api_base = 'https://twoj‑sklep.pl/wp-json/myshop/v1';
$license_key = 'ABCDEF123456';

// 1. Aktywacja
$activate = wp_remote_post("{$api_base}/license/activate", [
    'body' => [
        'license_key' => $license_key,
        'domain'      => home_url(),
    ],
]);
$activate_data = json_decode(wp_remote_retrieve_body($activate), true);
if (!$activate_data['ok']) {
    // obsłuż błąd
}

// 2. Walidacja
$validate = wp_remote_post("{$api_base}/license/validate", [
    'body' => [
        'license_key' => $license_key,
        'domain'      => home_url(),
    ],
]);
$status = json_decode(wp_remote_retrieve_body($validate), true);
if ($status['status'] !== 'active') {
    // licencja nieaktywna – pokaż komunikat
}

// 3. Sprawdzenie aktualizacji
$check = wp_remote_post("{$api_base}/updates/check", [
    'body' => [
        'license_key' => $license_key,
        'slug'        => 'moja‑wtyczka',
        'version'     => '1.0.0',
        'domain'      => home_url(),
    ],
]);
$update = json_decode(wp_remote_retrieve_body($check), true);
if (!empty($update['new_version'])) {
    // pobierz ZIP z $update['package'] i podaj WordPressowi
}
```

## 6. Integracja z innymi produktami (e‑booki)

Wtyczka rozróżnia produkty licencjonowane (wtyczki) od pozostałych (np. e‑booków). Jeśli klient kupił tylko e‑book,
zakładka **Moje konto → Licencje** oraz **Subskrypcje** nie są wyświetlane. Dzięki temu użytkownik nie jest
zdezorientowany dodatkowymi opcjami, których nie potrzebuje.

## Podsumowanie

Przedstawione przykłady pokazują typowe zastosowania wtyczki **License Server**. Dzięki jasnym komunikatom, kontroli
licencji i bezpiecznej dystrybucji aktualizacji zarówno Ty, jak i Twoi klienci możecie korzystać z wtyczek bez
obaw o nieautoryzowane użycie.

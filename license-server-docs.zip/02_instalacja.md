# Instalacja

## Wymagania wstępne

- PHP w wersji **8.0** lub wyższej.
- WordPress w wersji **6.2** lub wyższej.
- Aktywna wtyczka **WooCommerce** (wymagana).
- Opcjonalnie: wtyczka **WooCommerce Subscriptions** – tylko jeśli sprzedajesz licencje w modelu subskrypcyjnym.

## Instalacja wtyczki

1. Pobierz paczkę ZIP z wtyczką: `license-server-final.zip`.
2. W panelu administracyjnym WordPressa przejdź do **Wtyczki → Dodaj nową → Wyślij wtyczkę na serwer**.
3. Wybierz pobraną paczkę ZIP i kliknij **Zainstaluj**.
4. Po zakończeniu instalacji kliknij **Aktywuj wtyczkę**.

Wtyczka automatycznie utworzy niezbędne tabele w bazie danych i zarejestruje zadania cron. Jeśli instalacja przebiegła pomyślnie, w menu bocznym pojawią się nowe pozycje w sekcji WooCommerce (Licencje, Wydania, Ustawienia).

## Aktywacja i dezaktywacja

- **Aktywacja**: podczas aktywacji wtyczka uruchamia migracje bazy danych (`dbDelta`) i rejestruje zadania cron (`lsr_cron_housekeeping`), odpowiedzialne za czyszczenie wygasłych podpisów i linków.
- **Dezaktywacja**: wtyczka usuwa zarejestrowane zadania cron, ale **nie usuwa danych** z bazy. Aby całkowicie usunąć tabele i dane, użyj pliku `uninstall.php` (automatycznie uruchamianego przy trwałym usunięciu wtyczki w WordPressie).

## Struktura katalogów

Wtyczka posiada uporządkowaną strukturę plików. Najważniejsze katalogi to:

- **includes/** – zawiera główne komponenty wtyczki (API, Repozytoria, Serwisy, Integracje WooCommerce).
- **templates/** – szablony widoków (panel administracyjny, shortcode na froncie).
- **assets/** – pliki CSS i JS dla panelu administratora.
- **storage/releases/** – katalog na przesyłane pliki ZIP z wersjami wtyczek.
- **languages/** – pliki językowe w formacie `.po/.mo`.
- **tests/** – przykładowe testy jednostkowe i integracyjne (wymagają PHPUnit).

Ta struktura ułatwia odnalezienie konkretnego elementu i zapewnia rozdzielenie logiki biznesowej od warstwy prezentacji.